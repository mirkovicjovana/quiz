<?php
    require_once("db_utils.php");

    session_start();

    $baza = new Database();
   
    if(!isset($_SESSION['email'])){
    	header('location:login.php');
    }
   
?>

<!DOCTYPE html>
<html>
   <head>
        <link rel="stylesheet" href="css/style.css">
        <style>
          body {
            background-image: url("images/q5.jpg");
          }
        </style>
        <title>Quiz</title>
   </head>
   <body>

      <div class="container">

      	<?php 

      		if(isset($_SESSION['email'])){
   				$email=$_SESSION['email'];
   				}

      	?>
       
            <center>
              <div style="color:rgb(255, 230, 230)">
            	<?php echo $email ; ?>
               <h2><center>Srecno u QUIZ-u!!!</center></h2>
            <br>
            <p>Mozete izabrati samo jedan od ponudjenih odgovora na pitanje.</p>
      </div>
         
               <br>
    <div style="color:rgb(255, 230, 230)">
                  <form action="provera.php" method="post">
                        
                       <!--Ispisemo pitanja i ponudjene odgovore-->
                        <?php 
                           $niz_pitanja=$baza->pitanja();
                           foreach ($niz_pitanja as $pitanje) {
                              echo $pitanje->getHtml();
                           }


                        ?>
                        
                        <br>
                        <input type="submit" name="submit" Value="Proverite odgovore" class="myButton" /> <br>
                  </form>
               </div>
            <br>
            <a href="logout.php" class="myButton"><center><button> Logout</button></center></a> <br>
      </div>
   </body>
</html>
