<?php
	require_once("db_utils.php");

	$d = new Database();

	session_start();

	$errors=[];
	

	if (isset($_POST["login"])) {

		if(isset($_POST['email'])){
			$email =htmlspecialchars($_POST['email']);
		}
		
		if(isset($_POST['sifra'])){
			$sifra = htmlspecialchars($_POST['sifra']);
		}

		$korisnik = $baza->Login($email, $sifra);

		if (!$korisnik) {
			$errors["nepostojeci_korisnik"]="Korisnik sa tim podacima ne postoji. Pokusajte ponovo.";
			header( "Location: login.php" ); //kada refresh ponovo ce se $errors inicijalizovati na [] pa se nikad nece ispisati ova greska
		}else {
			$_SESSION["email"] = $email;
			header( "Location: home.php");
		}
	
	if (!$email) {
		$email = $_SESSION["email"];
	}
}
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="css/style.css">
		<style>
			body {
			  background-image: url("images/pozadina.jpg");
			}
		</style>
		<title>Login</title>
	</head>

	<body>

		<?php 
		//setujemo u provera.php
			if(isset($_COOKIE["prvoMesto"])){
				echo "Trenutno je na prvom mestu na rang listi " . $_COOKIE["prvoMesto"] . ". ";
			}
		?>
			<?php
				if(!empty($errors)){
					foreach ($errors as $e) {
						echo $e;
					}
				}
			?>
		<div class="box-body" style="color:rgb(255, 230, 230)">
			<center> <h5>Login to </h5><h4>QUIZ</h4></center><br>

			<form method="post" action="login.php">
				<center>
					<div class="form-group">
						<label>Unesite svoj email:</label>
						<input type="email" name="email" value="" required="">
					</div>
					<div class="form-group">
						<label>Unesite svoju sifru:</label>
						<input type="password" name="sifra" value="" required="">
					</div> 
					<div class="form-group text-right">
						<input type="submit" name="login" id="btn" value="Login" class="myButton" />
					</div>

			</form>
		</div>

		<br><br><br>
		<div class="form-group text-center" style="color:rgb(255, 230, 230)">
				<center><span class="text-muted">Niste registrovani?</span><br> Registrujte se <a href="register.php" class="myButton"><button>ovde</button></a></center>.
		</div>

	</body>


</html>