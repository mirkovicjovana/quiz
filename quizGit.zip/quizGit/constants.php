<?php

    define("TBL_REG", "podaci");
    define("COL_REG_ID","id");
    define("COL_REG_IME", "ime");
    define("COL_REG_PREZIME", "prezime");
    define("COL_REG_EMAIL", "email");
    define("COL_REG_SIFRA", "sifra");
    define("TBL_PIT","pitanja");
    define("COL_PIT_PID","pid");
    define("COL_PIT_PITANJE","pitanje");
    define("COL_PIT_OID", "odg_id");
    define("TBL_ODG","odgovori");
    define("COL_ODG_OID","oid");
    define("COL_ODG_ODGOVOR","odgovor");
    define("COL_ODG_PID","pit_id");
    define("TBL_K","korisnik");
    define("COL_K_ID","kid");
    define("COL_K_EMAIL","emailk");
    define("COL_K_TACNI", "tacni_odg");


    
    