<?php
  	require_once("constants.php");
    require_once("pitanje.php");
    require_once("korisnik.php");

 	class Database {
    
	    private $conn;
        private $hash="5FW#5Kk8nbJ}k#4#*dvG(q{g5";

	    public function __construct($configFile = "config.ini") {
			if($config = parse_ini_file($configFile)) {
				$host = $config["host"];
				$database = $config["database"];
				$user = $config["user"];
				$password = $config["password"];
                try{
				$this->conn = new PDO("mysql:host=$host;dbname=$database", $user, $password);
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                }catch(PDOException $e){
                    echo "Connection failed: ". $e->getMessage();
                }
			}
	    }

	    public function __destruct() {
	    	$this->conn = null;
	    }

        public function insertUser($ime,$prezime,$email,$sifra){
            //Ne dozvoljavamo dva korisnika u bazi sa istim email-om
            try {
                $sql_existing_user = "SELECT * FROM " . TBL_REG . " WHERE " . COL_REG_EMAIL . "= :email";
                $st = $this->conn->prepare($sql_existing_user);
                $st->bindValue(":email", $email, PDO::PARAM_STR);
                $st->execute();
                $existing_user=$st->fetch();
                //ako nam vrati neki konkretan red onda postoji vec korisnik sa tim emailom pa je neuspesno dodavanje-false
                if($existing_user){
                    return false;
                }

                //ako fetch() vrati false pravimo novog korinsika

                $nova_sifra = crypt($sifra, $this->hash);

                $sql_insert = "INSERT INTO " . TBL_REG . " (".COL_REG_IME.","
                                                              .COL_REG_PREZIME.","
                                                              .COL_REG_EMAIL.","
                                                              .COL_REG_SIFRA.")"   
                            ." VALUES (:ime, :prezime, :email, :sifra)";
                $st = $this->conn->prepare($sql_insert);
                $st->bindValue("ime", $ime, PDO::PARAM_STR);
                $st->bindValue("prezime", $prezime, PDO::PARAM_STR);
                $st->bindValue("email", $email, PDO::PARAM_STR);
                $st->bindValue("sifra", $nova_sifra, PDO::PARAM_STR);
                
                return $st->execute();

            } catch (PDOException $e) {
                echo $e->getMessage();
                return false;
            }
        }

        public function Login($email, $sifra){
            try {
                $nova_sifra = crypt($sifra, $this->hash);
                $sql = "SELECT * FROM " . TBL_REG . " WHERE " . COL_REG_EMAIL . "=:email and " . COL_REG_SIFRA . "=:sifra";
                $st = $this->conn->prepare($sql);
                $st->bindValue("email", $email, PDO::PARAM_STR);
                $st->bindValue("sifra", $nova_sifra, PDO::PARAM_STR);
                $st->execute();
                return $st->fetch(); 
            } catch (PDOException $e) {
                $e->getMessage();
                return false;
            }
        }

        
        public function brPitanja(){
            try {

                $sql= "SELECT * FROM " . TBL_PIT; 
                $st = $this->conn->query($sql);
                $redovi=$st->fetchAll();
                return count($redovi); 

            } catch (PDOException $e) {
                return false;
            }
        }

        public function pitanja(){

            $niz_pitanja=[];
            try {
                $sql_pit= "SELECT * FROM " . TBL_PIT;
                $st = $this->conn->query($sql_pit);
                $pitanja=$st->fetchAll(); 
                                                
                foreach ($pitanja as $p) {
                      
                    try{  
                        //izvlacimo sve ponudjene odg
                        $id=$p['pid'];
                        $sql_odg = "SELECT * FROM " . TBL_ODG . " WHERE " . COL_ODG_PID . "= :id"; 
                        $sto = $this->conn->prepare($sql_odg);
                        $sto->bindValue(":id", $id, PDO::PARAM_INT);
                        $sto->execute();
                        $ponudjeni=$sto->fetchAll(); 

                        //iz niza svih ponudjenih odg za to pitanje(4 ponudjena odg) izvucemo onaj koji je tacan
                        foreach ($ponudjeni as $o) {
                            //za tacan odg se poklapaju oid iz tabele odgovori i odg_id iz tabele pitanja
                                if($o[COL_ODG_OID]==$p['odg_id']){
                                    $tacan=$o;
                                    break;
                                }
                        } 
                        //pravim objekte klase Pitanje-arg konstruktora su mi: id,text pitanja, niz svih ponudjenih odg i tacan odg
                        $pitanje=new Pitanje($p['pid'],$p['pitanje'],$ponudjeni,$tacan['odgovor'],$p['odg_id']);
                        $niz_pitanja[]=$pitanje;

                    }catch(PDOException $e){
                        echo $e->getMessage();
                    }
                }
            }catch(PDOException $e){
                $e->getMessage();
            }

            return $niz_pitanja;
	   }

       //dodaje korisnika u tabelu korisnik
       public function dodajKorisnika($kemail,$br_tacnih){
            $korisnici=[];
            //Ni ovde ne dozvoljavamo 2 ista korisnika(Samo jednom se moze igrati sa jednog email-a)
             try {
                $sql_existing_user = "SELECT * FROM " . TBL_K . " WHERE " . COL_K_EMAIL . "= :email";
                $st = $this->conn->prepare($sql_existing_user);
                $st->bindValue(":email", $kemail, PDO::PARAM_STR);
                $st->execute();
                $existing_user=$st->fetch();
                if($existing_user){
                    return false;
                }

                $sql_insert = "INSERT INTO " . TBL_K . " (".COL_K_EMAIL.","
                                                              .COL_K_TACNI.")"   
                            ." VALUES (:kemail, :tacni)";
                $st = $this->conn->prepare($sql_insert);
                $st->bindValue("kemail", $kemail, PDO::PARAM_STR);
                $st->bindValue("tacni", $br_tacnih, PDO::PARAM_INT);
                return $st->execute();

            } catch (PDOException $e) {
                echo $e->getMessage();
                return false;
            }
       }

       //ovaj metod koristimo u provera.php kada korisnik zavrsi sa igrom da ga ubacimo u bazu sa njegovim osvojenim br poena
        public function korisnici(){

            $niz_korisnika=[];
            //iz tabele korisnik izvlacimo sve redove
            try {
                $sql= "SELECT * FROM " . TBL_K;
                $st = $this->conn->query($sql);
                $korisnici=$st->fetchAll(); 
                                                
                foreach ($korisnici as $k) {
                      
                        $email=$k['emailk'];
                        $br_tacnih_odg=$k['tacni_odg'];
                        $korisnik=new Korisnik($email,$br_tacnih_odg);
                        $niz_korisnika[]=$korisnik;
                }
            }
            catch(PDOException $e){
                $e->getMessage();
            }

            return $niz_korisnika;

       }

        public function brKorisnika(){
            try {

                $sql= "SELECT * FROM " . TBL_K; 
                $st = $this->conn->query($sql);
                $redovi=$st->fetchAll();
                return count($redovi); 

            } catch (PDOException $e) {
                return false;
            }
        }
    }

?>