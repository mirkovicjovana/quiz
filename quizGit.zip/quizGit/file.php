<?php
    require_once("parser.php");

    $filename = "";

    if (isset($_POST["sendFile"])) {
        if(isset($_FILES["podaci"]) && is_uploaded_file($_FILES["podaci"]["tmp_name"])) {
            processForm();
            $filename = "files/" . basename($_FILES["podaci"]["name"]);
            parse($filename);

        } else {
            redirect();
        }
    }


    if (isset($_GET["filename"])) {
        $filename = "files/" . $_GET["filename"];
        if (!file_exists($filename)) {
            redirect();
        }
    }

    function processForm() {
        global $message;

        if ($_FILES["podaci"]["error"] == UPLOAD_ERR_OK ) {
            if (!move_uploaded_file($_FILES["podaci"]["tmp_name"], "files/" . basename( $_FILES["podaci"]["name"]))) {
                $message = "Sorry, there was a problem uploading that file.";
            }
        } else {
            switch( $_FILES["podaci"]["error"] ) {
                case UPLOAD_ERR_INI_SIZE:
                    $m = "The file is larger than the server allows.";
                    break;
                case UPLOAD_ERR_FORM_SIZE:
                    $m = "The file is larger than the script allows.";
                    break;
                default:
                    $m = "Please contact your server administrator for help.";
            }
            $message = "Sorry, there was a problem uploading that file. $m";
        }
    }

    function redirect() {
        echo("<script>
                alert(\"Please upload or select a file...\");
                window.location.replace(\"./\");
            </script>");
    }
      
?>


<!DOCTYPE html>
<html>
  <head>
      <link rel="stylesheet" href="css/style.css">
      <style>
        body {
          background-image: url("images/pozadina.jpg");
        }
      </style>
      <title>Uploading a File</title>
  </head>
  <body>
    <div style="color:rgb(255, 230, 230)">
          <h1>Uploading a File</h1>

          <p>Izaberite file za dodavanje i posaljite ga.</p>

          <form action="file.php" method="post" enctype="multipart/form-data">
            <div style="width: 30em;">
              <input type="hidden" name="MAX_FILE_SIZE" value="500000" />

              <label for="podaci">Vas file</label>
              <input type="file" name="podaci" id="file" value="Upload file" accept=".csv"/>

              <div style="clear: both;">
                <input type="submit" name="sendFile" value="Posaljite file"/>
              </div>

            </div>
          </form>
  </body>
</html>
