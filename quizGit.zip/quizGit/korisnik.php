<?php

   require_once("db_utils.php");
   require_once("pitanje.php");

   $baza = new Database();

    class Korisnik{

        private $email;
        private $poeni;

        public function __construct($email,$poeni) {
            $this->email = $email;
            $this->poeni = $poeni;
        }

        public function getEmail() {
            return $this->email;
        }

        public function getPoeni() {
            return $this->poeni;
        }

        //opadajuce(da bi korisnik sa najvise poena bio na 1.mestu)
        public static function poredjenje(Korisnik $korisnik1, Korisnik $korisnik2) {
            if ($korisnik1->getPoeni() > $korisnik2->getPoeni()) {
                return -1;
            } elseif ($korisnik1->getPoeni() < $korisnik2->getPoeni()) {
                return 1;
            } else {
                return 0;
            }
        }

        public function getHTMLKorisnik(){
            $html="";
            $html.=$this->email . " " . $this->poeni . "<br>";           
            return $html;
        }
    }
