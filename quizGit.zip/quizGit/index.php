<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="css/style.css">
	<style>
		body {
		  background-image: url("images/q4.jpg");
		}
	</style>
	<title>QUIZ</title>
</head>
<body>
	<div id="header" style="color:rgb(255, 230, 230)">
			<ul>
				<h1><center>Dobrodosli u QUIZ!</center></h1>

				<h2><center>Zelite li da se registrujete?</center></h2>
				<h3><center>Ukoliko nemate jos uvek napravljen profil za igranje QUIZ-a registrujte se <a href="register.php" class="myButton"><button> OVDE </button></a></center></h3>
				<!--Klikom na ovde prebacuje nas na stranicu za registraciju-->
				

				<h2><center>Ili vec imate napravljen profil?</center></h2>
				<h3><center>Ukoliko vec imate napravljen profil za igranje QUIZ-a ulogujte se <a href="login.php" class="myButton"><button> OVDE </button></a></center></h3>
				<!--Klikom na ovde prebacuje nas na stranicu da se ulogujemo-->
			</ul>
	</div>
</body>
</html>