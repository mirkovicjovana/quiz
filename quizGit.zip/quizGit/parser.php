<?php 
    require_once("db_utils.php");

    $errors = [];
    function parse($filename) {

        global $message;
        $ime=$prezime=$email=$sifra=$ponovljena_sifra="";
        $baza=new Database();
        $file = fopen($filename, "r");

        if ($file) {
            while ($line = fgetcsv($file, 0, ";")) {

                $ime=htmlspecialchars($line[0]);
                $prezime=htmlspecialchars($line[1]);
                $email=htmlspecialchars($line[2]);
                $sifra=htmlspecialchars($line[3]);
                $ponovljena_sifra=htmlspecialchars($line[4]);

                if ($sifra != $ponovljena_sifra){
                    $errors["poklapanjeSifri"] = "Sifre se ne poklapaju.Pokusajte ponovo.";
                }

                if(empty($errors)){
                    $novi_korisnik = $baza->insertUser($ime,$prezime,$email,$sifra);
                    if($novi_korisnik){
                        $message = "Uspesno ste se registrovali.";
                    }else{
                        $message = "Nespesna registracija.Pokusajte ponovo.";
                    }
                }
            }
            fclose($file);
        }

    }
?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

    <?php 

        if(!empty($errors)){
                foreach ($errors as $error) {
                    echo "<div>{$error}</div>";
                }
            }
            
        if(isset($message)){
                    echo $message;
                }
            
    ?>
    <header>
        <div class="form-group text-center">
                <span class="text-muted">Zelite da se ulogujete sada i igrate QUIZ?</span><br> Ulogujte se <a href="login.php"><button>ovde</button></a>.
        </div>
   </header>

</body>
</html>