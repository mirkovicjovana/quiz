<?php 
	require_once "db_utils.php";

	$baza = new Database(); 
	$errors = [];
	$messages=[];
	$ime=$prezime=$email=$sifra=$ponovljena_sifra="";

	if(isset($_POST['submit']))
	{	
		if(isset($_POST['ime'])){
			$ime=htmlspecialchars($_POST['ime']);
		}

		if(isset($_POST['prezime'])){
			$prezime=htmlspecialchars($_POST['prezime']);
		}

		if(isset($_POST['email'])){
			$email =htmlspecialchars($_POST['email']);
		}
		
		if(isset($_POST['sifra'])){
			$sifra = htmlspecialchars($_POST['sifra']);
		}

		if(isset($_POST['ponovljena_sifra'])){
			$ponovljena_sifra =$_POST['ponovljena_sifra'];
		}
    }

    if ($sifra != $ponovljena_sifra){
			$errors["poklapanjeSifri"] = "Sifre se ne poklapaju.Pokusajte ponovo.";
		}

	//Ako su uneti svi podaci i sifre se poklapaju unosimo korisnika u bazu
	if(empty($errors)){
		$novi_korisnik = $baza->insertUser($ime,$prezime,$email,$sifra);
		if($novi_korisnik){
			$messages["uspesna_registracija"]="Uspesno ste se registrovali.";
			//dodali prvi uslov da ne bi ispisivalo da je neuspesna reg i pre nego sto pokusamo da se reg
		} elseif(isset($_POST['submit']) && !$novi_korisnik){
				$messages["neuspesna_registracija"]="Nespesna registracija.Pokusajte ponovo da se registrujete sa nekim drugim email-om.";
			}
		}
	
?>

<html>
	<head>
		<link rel="stylesheet" href="css/style.css">
			<style>
				body {
				  background-image: url("images/pozadina.jpg");
				}
			</style>
		<title>Registracija</title>
	</head>
	<body>
		<div style="color:rgb(255, 230, 230)">
			<center> <h5>Registrujte se</h5><h4>QUIZ</h4></center><br>
		

		<?php 
			if(!empty($errors)){
				foreach ($errors as $error) {
					echo "<div>$error</div>";
				}
			}
		?>
	

		
		<form method="post" action="">
           
           <p>
           <center> 
	            <div class="form-group">                  
					<label>Unesite svoje ime:</label>
					<input type="text" name="ime" required="" value="<?php echo $ime;?>" /> 
				</div>

				 <div class="form-group">
					<label>Unesite svoje prezime:</label>
					<input type="text" name="prezime" required="" value="<?php echo $prezime;?>"/>
				</div>
				
				 <div class="form-group">
					<label>Unesite svoj email:</label>
					<input type="text" name="email" required="" value="<?php echo $email;?>"/> 
				</div>

				 <div class="form-group">
					<label>Unesite svoju sifru:</label>
					<input type="password" name="sifra" required="" value="<?php echo $sifra;?>"/>
				</div>

				 <div class="form-group">
					<label>Ponovite svoju sifru:</label>
					<input type="password" name="ponovljena_sifra" required="" value="<?php echo $ponovljena_sifra;?>" />
				</div>
			</center>
			</p>

			<p>
				<center><input type="submit" name="submit" value="Registrujte se"></center> 
			</p>

		</form>


		<?php
				if (!empty($messages)) {
					foreach ($messages as $message) {
						echo "<center><div>$message</div></center>";
					}
				}
			?>

		<br><br><br>

		<center>
		<div class="form-group text-center">
				<span class="text-muted">Zelite da se registrujete upload-ovanjem file-a?</span><br> To mozete uraditi <a href="file.php"><button>ovde</button></a>.<br><br>
		</div>

		<br><br><br>
	
		<div class="form-group text-center">
				<span class="text-muted">Zelite da se ulogujete sada i igrate QUIZ?</span><br> Ulogujte se <a href="login.php"><button>ovde</button></a>.
		</div>
	</center>
</div>

	</body>
</html>