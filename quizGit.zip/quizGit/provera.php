<?php
   require_once("db_utils.php");
   require_once("pitanje.php");
   require_once("korisnik.php");

   session_start();

   $baza = new Database();
   $br_tacnih=0;
   $niz_pitanja=$baza->pitanja();
   $brojac_pitanja=0;
   $pogresni=[];
   $html="";
   $prvi="";

   //u pitanje.php napravljen radio input koji kao name ima provera[$id] 
   //provera je niz pomocu kog proveravamo pod iz post forme-ako je korisnik odg na 3.pit onda ce provera[3] sadrzati vrednost njegovog odg (value=$o['oid'])
    if(isset($_POST['submit'])){
	   	if(!empty($_POST['provera'])){

	   		$br_odgovora = count($_POST['provera']);
	   		if($br_odgovora!=$baza->brPitanja()){
	   					$html.= "Niste odgovorili na sva pitanja. Pokusajte ponovo.<br>Vrati se na <a href=\"home.php\"><button>pitanja</button></a>.";	
	            	}else{
	            		$korisnikovi_odg = $_POST['provera'];
	        
	        			//proveravamo da li je korisnikov odg tacan
	            		foreach ($korisnikovi_odg as $key => $value) {
	            			//$key-1 jer indeksi u $niz_pitanja krecu od 0(tu nije namesteno kao u $korisnikovi_odg da krecu kljucevi od 1-jer su izvuceni iz tabele gde smo stavili id-eve da krecu od 1)
	            			if(($niz_pitanja[$key-1])->getTacanID()==$value){
	            				$br_tacnih=$br_tacnih+1;
	            			}else{
	            				$pogresni[]=($niz_pitanja[$key-1]); //niz objekata klase Pitanje
	            			}
	            		}

	            		$html.= "Tacno ste odgovorili na ". $br_tacnih . " od " . $baza->brPitanja() . " pitanja.<br><br>";

	            		if($br_tacnih==$baza->brPitanja()){
	            			$html.= "<br> Bravo! Znali ste odgovore na sva pitanja!<br><br><br>";
	            		}else{
	            			$html.="<br>Pogresno ste odgovorili na sledeca pitanja: <br><br>";
	            			foreach ($pogresni as $pogresan) {
	            				$html.= $pogresan->getIDPitanja() . ". " . $pogresan->getTextPitanja() . "<br>" . "Tacan odgovor na to pitanje je ". $pogresan->getTextTacnogOdg() . ".<br><br>" ;
	            			}
	            		}

	            	}
	    }
 	}

 	$kemail = $_SESSION['email'];
 	$baza->dodajKorisnika($kemail,$br_tacnih);
 	$korisnici=$baza->korisnici(); 

 	if(isset($_GET['rang'])){
 		$html.="<br><br>Poredak na rang listi je sledeci: <br>";
	  	$funkcija='Korisnik::poredjenje';
	 	usort($korisnici,$funkcija);
	 	$br_korisnika=$baza->brKorisnika();

	 	$prvi=($korisnici[0])->getEmail();

	 	foreach ($korisnici as $key=>$value) {
	 		//$key je redni br korisnika u sortiranom nizu, pri cemu indeksi krecu od 0 pa dodamo 1 za redni broj
	 		$redni_broj=$key+1;
	 		$html.= $redni_broj . ".    " . $value->getHTMLKorisnik(); 
	 	}
 	}

 	setcookie( "prvoMesto", $prvi, time() + 60 * 60 * 24 * 365, "/", "", false, true );


?>
<!DOCTYPE html>
<html>
   <head>
	   	<link rel="stylesheet" href="css/style.css">
		<style>
			body {
			  background-image: url("images/pozadina.jpg");
			}
		</style>
        <title>Rezultati</title>
 <body>

     <div class="container text-center" style="color:rgb(255, 230, 230)">
     	<br>
    	<h2 class="text-center"><center> QUIZ</center> </h2>
    	<br><br>
      	<h1 class="text-center"><center> Rezultati </center></h1>

     <br>

       <center>
     <?php
 	if(isset($html)){
 		echo $html;
 	}

 	?>
 	</center>
 
 	<?php 
 		//Da ne bismo mogli opet kliknuti na rang ako nam se vec prikazuje rang lista
 		if(!isset(($_GET['rang']))){
 	?>

     <form method="get" action="">
     	<br> <center>Zelite li da vidite rang listu? Ako zelite kliknite na <input type="submit" name="rang" value="rang lista" class="myButton"> .  </center><br><br>
     </form>

     <?php 
     	}
     ?>


 	<br><br><br>
      		
      
	<center><a href="logout.php" class="myButton"><button> Logout</button></a></center> <br>
</div>
      
   </body>
</html>