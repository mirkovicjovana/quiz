<?php

	class Pitanje{

		private $id; //id pitanja
		private $text_pitanja;
		private $ponudjeni_odgovori; //niz ponudjenih odg od 4 el
		private $tacan_odgovor; //text tacnog odgovora
		private $tacan_id; //id tacnog odg

		public function __construct($id,$text,$ponudjeni,$tacan,$tacan_id){
			$this->id=$id;
			$this->text_pitanja=$text;
			$this->ponudjeni_odgovori=$ponudjeni;
			$this->tacan_odgovor=$tacan; 
			$this->tacan_id=$tacan_id;
		}

    	public function getHTML() {
			$redni_br=1;
			$html="";

			//ispis pitanja
			$html.="<div class=\"card\">
			<p class=\"card-header\">". $this->id . ". ".$this->text_pitanja . "</p>";

			//ispis ponudjenih odgovora
			foreach ($this->ponudjeni_odgovori as $o) {
				$id=$o['pit_id'];
				$html.="<div class=\"card-block\">";
				//Ako hocemo i redni br.pored pitanja
				//$html.="<input type=\"radio\" name=\"provera[$id]\" id=\"$id\" value=\"".$o['oid']."\">" .$redni_br.". ". $o['odgovor'] . "<br>";

				//u niz provera smestamo odgovore korisnika-kljucevi tog niza su id pit, a vred su korisnikovi odg
				//npr: [1]=>korisnikov odg na 1.pitanje
				$html.="<input type=\"radio\" name=\"provera[$id]\" id=\"$id\" value=\"".$o['oid']."\">". $o['odgovor'] . "<br>";
				$html.="</div>";
				//$redni_br=$redni_br+1;
			}

			$html.="</div>";

	        return $html;
    	}

	    public function getTextTacnogOdg(){
	    	return $this->tacan_odgovor;
	    }

	    public function getTacanID(){
	    	return $this->tacan_id;
	    }

	    public function getIDPitanja(){
	    	return $this->id;
	    }

	    public function getTextPitanja(){
	    	return $this->text_pitanja;
	    }


	}
?>